<?php
if( ! defined ('DBHOST')){
    define('DBHOST', 'localhost');
}
if( ! defined ('DBUSER')){
    define('DBUSER', 'root');
}
if( ! defined ('DBPASS')){
    define ('DBPASS', '');
}
if( ! defined('DBNAME')){
    define('DBNAME', 'webcourse');
}
if ( ! defined('CHARSET')){
    define('CHARSET', 'utf8mb4');
}
$dbhost = DBHOST;
$dbuser = DBUSER;
$dbpass = DBPASS;
$dbname = DBNAME;

$charset = CHARSET;
