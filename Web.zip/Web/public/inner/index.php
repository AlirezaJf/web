<?php
include 'includes/functions.php';
redirect('../');